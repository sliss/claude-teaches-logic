# Unit 1: Propositional Logic — Exercises

## Instructions

Work through these exercises as you complete each section. Record your attempts in `attempts.md` in this directory. Solutions will be added after you've attempted the problems.

---

## 1.1 Syntax

*Exercises to be added after covering 1.1*

---

## 1.2 Semantics

*Exercises to be added after covering 1.2*

---

## 1.3 Semantic Entailment

*Exercises to be added after covering 1.3*

---

## 1.4 Proof Systems

*Exercises to be added after covering 1.4*
