# Unit 1: Propositional Logic — Attempts

Record your exercise attempts here with timestamps.

---

## Template

### Exercise X.Y.Z — [Date]

**Problem:** [Restate briefly]

**Attempt:**

[Your work here]

**Self-assessment:** [Correct / Partially correct / Stuck]

**Notes:** [What you learned, what was confusing]

---

## Attempts

*(Add your attempts below)*
